import 'dotenv/config';
import pg from 'pg';
export const pool = new pg.Pool({connectionString:process.env.DATABASE_URL, max:12, idleTimeoutMillis:30000});
export const query=(sql,params=[])=>pool.query(sql,params);
